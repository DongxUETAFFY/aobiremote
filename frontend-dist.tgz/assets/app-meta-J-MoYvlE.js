const A="v1.0.8",P="2026-04-30";export{A,P as a};
